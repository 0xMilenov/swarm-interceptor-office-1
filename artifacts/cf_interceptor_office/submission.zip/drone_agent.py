"""Office interceptor agent.

A classical controller for the indoor Tello interceptor task: find a target
drone inside a fixed office and physically hit it.

Pipeline, once per control step:

  1. Decode the telemetry packet and dead-reckon. World yaw is reported
     absolutely, so body velocity integrates into a frame whose origin is
     arbitrary but whose heading is real. Height is measured, never integrated.
  2. Turn any fresh detector box into a 3-D relative vector by inverting the
     camera projection: bearing from the box centre, range from its apparent
     size. The box is back-projected through the pose held when it was
     captured, not the current pose, since the observation reports its own age.
  3. Associate and confirm sightings in world space. A false positive is sized
     from a distance redrawn every frame, so a ghost jumps metres in 3-D while
     appearing to sit still on screen; a world-space gate separates the two
     almost for free.
  4. Run the phase machine and its guidance law.
  5. Keep to space that has been shown flyable, bound altitude, bound the
     velocity error by the remaining tilt margin, then convert to sticks.

Both the chaser and the target are reconstructed in the same drifting frame,
so the arbitrary origin cancels in their difference and the relative geometry
guidance reads stays sound.

obs["rgb"] is unused: with no absolute position fix a wall map could not be
registered, so free space is instead accumulated from the target's own flown
path and from the positions this drone has already survived.

Contract

  obs["state"] (127,)
     0:4    pitch, roll (rad), sin(yaw), cos(yaw)      -- yaw is WORLD absolute
     4:7    body velocity forward, right, DOWN (m/s)
     7:10   body specific force fwd, right, down (hover reads -9.8 on down)
    10:15   ToF (m, <=8), fused height (m), baro (m), packet age (s), valid
    15:27   n_boxes, age_since_box (s), then 2 x [cx, cy, w, h, conf] in [0,1]
    27:127  last 25 actions, 4 each
  action (4,)  [lr, fb, ud, yaw] in [-1, 1], body frame, full stick = 3.0 m/s,
               yaw is a RATE (full = 3.141 rad/s)
"""

from __future__ import annotations

import math
from collections import deque
from typing import Optional, Tuple

import numpy as np

# ---------------------------------------------------------------------------
# Environment constants. Mirrored from swarm/constants.py at authoring time so
# the submission stays standalone. Anything the env can change under us is
# flagged; nothing here is fitted.
# ---------------------------------------------------------------------------
CONTROL_HZ = 50.0
DT = 1.0 / CONTROL_HZ
HORIZON_S = 60.0

RC_SPEED = 3.0                  # m/s at full stick, per axis
RC_YAW_RATE = 3.141             # rad/s at full yaw stick
RC_DEAD_ZONE = 0.05             # |stick| below this is read as zero by the env
RC_SLEW_PER_SEC = 4.0           # env slew-limits stick change: 0.08 units/step
RC_YAW_LEAD_RAD = 0.6           # env clamps how far the yaw setpoint may lead

MAX_TILT_DEG = 60.0             # tilt beyond this truncates the episode (TILT)
CAMERA_RES = 256.0
CAMERA_FOV_DEG = 90.0           # seeded +-2 deg; we use nominal (=> ~3.5% range bias)
CAMERA_EYE_FWD_M = 0.13
CAMERA_EYE_UP_M = 0.05
SPAWN_Z = 0.05

CEILING_M = 3.0
TARGET_ALT_MIN_M = 1.3          # the band the target flies in
TARGET_ALT_MAX_M = 2.6
TARGET_SPEED_MAX = 1.8          # cruise; flee tops out at 1.95, still under ours
TARGET_FLEE_MAX = 1.95

DET_TARGET_W_M = 0.18           # what the detector sizes its boxes from
DET_TARGET_H_M = 0.08
DET_CONF_FLOOR = 0.25
DET_STALE_SEC = 0.8
TELEM_STALE_SEC = 0.5
TOF_MAX_M = 8.0

# Focal length in pixels for the nominal FOV. The env draws FOV per episode from
# 90 +- 2 deg, so every range we derive from box size carries up to ~3.5% scale
# error. That is a bias, not noise: it never averages out; estimating it online
# from range-vs-closing consistency would remove it.
FOCAL_PX = (CAMERA_RES * 0.5) / math.tan(math.radians(CAMERA_FOV_DEG) * 0.5)

# ---------------------------------------------------------------------------
# Tunables. First-pass values, reasoned from the env constants above, not swept.
# ---------------------------------------------------------------------------
TAKEOFF_TARGET_M = 1.9          # mid of the target band
TAKEOFF_UD_STICK = 0.55         # full stick would hit the 3 m ceiling
TAKEOFF_DONE_M = 1.55

SEARCH_YAW_RATE = 1.2           # rad/s: ~13 detector frames per FOV crossing
SEARCH_ALT_LOW_M = 1.5          # slow vertical sweep varies the view geometry
SEARCH_ALT_HIGH_M = 2.4
SEARCH_ALT_PERIOD_S = 9.0
SEARCH_VZ_MAX = 0.6

ALT_MIN_M = 0.9                 # hard band we refuse to leave
ALT_MAX_M = 2.65                # 0.35 m of ceiling margin
TOF_FLOOR_GUARD_M = 0.55        # something solid below (a desk): climb

CONFIRM_HITS = 3                # 3-of-5 confirmation at the detector's rate
CONFIRM_WINDOW = 5
ASSOC_GATE_M = 1.10             # 3-D association gate; ghosts jump 2-12 m
ASSOC_GATE_RATE_M_PER_S = 3.0   # gate widens with how stale the track is
ASSOC_GATE_MAX_M = 3.0          # ...but never far enough to swallow a ghost
TRACK_DROP_S = 1.20             # no association for this long -> track dropped
VEL_HISTORY = 12                # detector frames (~1.2 s) for the velocity fit
VEL_EMA = 0.35
TARGET_VEL_CLAMP = 2.2          # above flee speed, below anything physical

RANGE_MIN_M = 0.12              # below this the box is unusable
RANGE_MAX_M = 20.0              # longer than the room's diagonal

PURSUE_SPEED = 3.0
TERMINAL_RANGE_M = 1.3          # inside this, aim straight at the predicted body
CONTACT_LEAD_S = 0.10           # small lead so we hit where it will be
YAW_LEAD_S = 0.12
YAW_KP = 2.4                    # rad/s per rad of bearing error
YAW_POINTING_ERR_RAD = math.radians(35.0)   # beyond this, yaw dominates

REACQUIRE_HOLD_S = 0.8          # fly the prediction before sweeping
REACQUIRE_SWEEP_RATE = 1.4
REACQUIRE_MAX_BIAS_RAD = math.radians(70.0)
REACQUIRE_GIVE_UP_S = 3.5       # back to open search

# A fleeing target leaves at up to 1.95 m/s, so a long extrapolation lands
# outside the room and we fly into the wall chasing a point that is not there.
TRACK_PREDICT_MAX_S = 0.5       # cap on forward extrapolation of the track
REACQ_EXTRAP_MAX_S = 0.8
REACQ_EXTRAP_MAX_M = 1.5        # and never further than this from the last fix
STALE_OVERSHOOT_M = 0.8         # how far past a stale fix we are willing to fly

# Free-space memory: every point the target was confirmed at is reachable
# space, and every point already survived is too; nothing else is vouched for.
FREE_ENABLED = True
FREE_SELF_R = 0.90              # our own wake: we flew it and lived
FREE_TARGET_R = 0.55            # a single noisy fix vouches for less
FREE_SPACING_M = 0.35           # downsample so the cloud stays small
FREE_LOOKAHEAD_S = 0.7
FREE_MAX_POINTS = 4000
FREE_LEG_MAX_GAP_S = 0.30       # only consecutive fixes describe a leg it flew
FREE_LEG_MAX_M = 6.0
FREE_CLOSE_EXEMPT_S = 0.5       # a fresh fix is reachable space by definition
FREE_CLOSE_ALIGN = 0.30

# Attitude governor: bound the VELOCITY ERROR as a function of the tilt margin
# actually left, applied to the command that is actually sent. A fixed clip
# binds identically whether the airframe is level with bank in hand or already
# near its limit; scaling with the remaining margin does not.
GOV_TILT_LIMIT_DEG = MAX_TILT_DEG
GOV_TILT_FREE_DEG = 22.0
GOV_ERR_MAX_MPS = 3.0
GOV_ERR_MIN_MPS = 0.45
GOV_PREDICT_S = 0.18            # differentiated attitude, not the reported rate


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def wrap_angle(a: float) -> float:
    return math.atan2(math.sin(a), math.cos(a))


def unit(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, dtype=np.float64)
    n = float(np.linalg.norm(v))
    return v / n if n > 1e-9 else np.zeros_like(v)


def clamp(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else (hi if x > hi else x)


def rot_from_rpy(roll: float, pitch: float, yaw: float) -> np.ndarray:
    """PyBullet convention: R = Rz(yaw) @ Ry(pitch) @ Rx(roll)."""
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    return np.array([
        [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
        [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
        [-sp,     cp * sr,                cp * cr],
    ], dtype=np.float64)


def body_axes_to_world(vf: float, vr: float, vu: float, yaw: float) -> np.ndarray:
    """Inverse of the env's world_to_body (forward, right, up) at this yaw."""
    c, s = math.cos(yaw), math.sin(yaw)
    return np.array([c * vf + s * vr, s * vf - c * vr, vu], dtype=np.float64)


def world_to_sticks(v_world: np.ndarray, yaw: float) -> Tuple[float, float, float]:
    """World velocity -> (lr, fb, ud) sticks. Exact inverse of the env's
    rc_sticks_to_world_velocity, so a stick we send means what we think."""
    c, s = math.cos(yaw), math.sin(yaw)
    fb = (c * v_world[0] + s * v_world[1]) / RC_SPEED
    lr = (s * v_world[0] - c * v_world[1]) / RC_SPEED
    ud = v_world[2] / RC_SPEED
    return lr, fb, ud


# ---------------------------------------------------------------------------
# telemetry decode + dead reckoning
# ---------------------------------------------------------------------------
class DeadReckoner:
    """Position is not observable in this family. We integrate the reported body
    velocity through the reported absolute yaw.

    The result is a frame whose ORIGIN is arbitrary (our spawn point) and which
    drifts with velocity-noise integration. That is fine for interception: the
    target is reconstructed in the same frame from our own pose, so the relative
    vector -- the only thing guidance reads -- carries no accumulated error.
    It is NOT fine for wall avoidance, which is not attempted here.
    """

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.pos = np.zeros(3, dtype=np.float64)     # z is overwritten by height
        self.vel = np.zeros(3, dtype=np.float64)
        self.yaw = 0.0
        self.pitch = 0.0
        self.roll = 0.0
        self.height = 0.0
        self.tof = TOF_MAX_M
        self.valid = False
        self.age = 0.0
        self._have_packet = False

    def update(self, state: np.ndarray) -> None:
        self.pitch = float(state[0])
        self.roll = float(state[1])
        sin_y, cos_y = float(state[2]), float(state[3])
        if abs(sin_y) > 1e-6 or abs(cos_y) > 1e-6:
            self.yaw = math.atan2(sin_y, cos_y)

        vf, vr, vdown = float(state[4]), float(state[5]), float(state[6])
        self.tof = float(state[10])
        self.height = float(state[11])
        self.age = float(state[13])
        self.valid = bool(state[14] > 0.5)

        if self.valid:
            self._have_packet = True
            # SDK convention: the third velocity component is positive DOWNWARD.
            self.vel = body_axes_to_world(vf, vr, -vdown, self.yaw)
        elif not self._have_packet:
            self.vel = np.zeros(3, dtype=np.float64)
        # stale packet: hold the last velocity rather than zeroing it, so a
        # dropped packet does not put a step discontinuity into the estimate.

        self.pos[0] += self.vel[0] * DT
        self.pos[1] += self.vel[1] * DT
        # Height is measured, so never integrate it: use the fused value plus
        # the takeoff offset to get a world z.
        self.pos[2] = self.height + SPAWN_Z

    @property
    def tilt_deg(self) -> float:
        return math.degrees(max(abs(self.roll), abs(self.pitch)))


# ---------------------------------------------------------------------------
# detector: box -> relative position
# ---------------------------------------------------------------------------
class Sighting:
    __slots__ = ("t_obs", "pos", "range_m", "bearing", "elevation", "conf", "slot")

    def __init__(self, t_obs, pos, range_m, bearing, elevation, conf, slot):
        self.t_obs = t_obs          # when the box was actually TRUE, not read
        self.pos = pos              # world (dead-reckoned frame)
        self.range_m = range_m
        self.bearing = bearing      # rad, +right of the nose
        self.elevation = elevation  # rad, +above
        self.conf = conf
        self.slot = slot


class BoxProjector:
    """Invert the camera projection to recover a 3-D relative vector.

        px = f * (rel . right) / depth + res/2
        py = f * (rel . -up)   / depth + res/2
        w  = f * 0.18 / depth,   h = f * 0.08 / depth

    so a box gives a full 3-D relative vector: bearing from the centre, range
    from the apparent size. Range is the weak axis -- 12% size jitter and a
    ~3.5% FOV scale bias -- which is exactly why the tracker below gates on
    3-D consistency instead of trusting any single measurement.
    """

    def __init__(self) -> None:
        # pose history, so a box can be back-projected through the pose we held
        # when it was captured rather than the pose we hold now
        self._poses: deque = deque(maxlen=int(2.0 / DT))

    def reset(self) -> None:
        self._poses.clear()

    def push_pose(self, t: float, pos: np.ndarray, roll: float, pitch: float, yaw: float) -> None:
        self._poses.append((t, pos.copy(), roll, pitch, yaw))

    def _pose_at(self, t: float):
        if not self._poses:
            return None
        best = self._poses[-1]
        for entry in reversed(self._poses):
            if entry[0] <= t:
                best = entry
                break
        return best

    def parse(self, state: np.ndarray, t_now: float) -> list:
        n_boxes = int(round(float(state[15])))
        if n_boxes <= 0:
            return []
        age = float(state[16])
        # obs age is measured from the frame the boxes describe, so it IS the
        # total sighting lag (inference delay included).
        pose = self._pose_at(t_now - age)
        if pose is None:
            return []
        _, p_obs, roll, pitch, yaw = pose
        rot = rot_from_rpy(roll, pitch, yaw)
        fwd, left, up = rot[:, 0], rot[:, 1], rot[:, 2]
        right = -left
        eye = p_obs + fwd * CAMERA_EYE_FWD_M + up * CAMERA_EYE_UP_M

        out = []
        for i in range(min(n_boxes, 2)):
            base = 17 + 5 * i
            cx, cy = float(state[base]), float(state[base + 1])
            w, h = float(state[base + 2]), float(state[base + 3])
            conf = float(state[base + 4])
            if conf < DET_CONF_FLOOR or w <= 1e-6 or h <= 1e-6:
                continue
            w_px, h_px = w * CAMERA_RES, h * CAMERA_RES
            # Two independent range estimates from the same 12%-jitter draw;
            # averaging them is a free sqrt(2) of noise reduction.
            depth_w = FOCAL_PX * DET_TARGET_W_M / w_px
            depth_h = FOCAL_PX * DET_TARGET_H_M / h_px
            depth = 0.5 * (depth_w + depth_h)
            if not (RANGE_MIN_M < depth < RANGE_MAX_M):
                continue
            x_r = (cx * CAMERA_RES - CAMERA_RES * 0.5) / FOCAL_PX     # right / depth
            y_d = (cy * CAMERA_RES - CAMERA_RES * 0.5) / FOCAL_PX     # down  / depth
            rel = fwd * depth + right * (depth * x_r) + up * (-depth * y_d)
            pos = eye + rel
            rng = float(np.linalg.norm(rel))
            out.append(Sighting(
                t_obs=t_now - age,
                pos=pos,
                range_m=rng,
                bearing=math.atan2(x_r, 1.0),
                elevation=math.atan2(-y_d, 1.0),
                conf=conf,
                slot=i,
            ))
        return out


# ---------------------------------------------------------------------------
# tracker
# ---------------------------------------------------------------------------
class TargetTracker:
    """Track the target across an intermittent 10 Hz sighting channel.

    The office detector emits ~0.9% false positives per frame, biased toward a
    couple of persistent image anchors -- so a ghost can sit still on screen.
    But its box is sized from a distance redrawn uniformly in [2, 12] m every
    frame, so the ghost's implied 3-D position hops metres between frames.
    A 3-D association gate therefore separates real from ghost almost for free.
    That is the single reason this tracker gates in world space and not in
    pixel space.
    """

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.confirmed = False
        self.pos: Optional[np.ndarray] = None
        self.vel = np.zeros(3, dtype=np.float64)
        self.last_t = -1e9
        self._samples: deque = deque(maxlen=VEL_HISTORY)
        self._pending: deque = deque(maxlen=CONFIRM_WINDOW)

    # -- queries ---------------------------------------------------------
    def missing_time(self, t: float) -> float:
        return t - self.last_t if self.pos is not None else 1e9

    def predict(self, t: float) -> Optional[np.ndarray]:
        if self.pos is None:
            return None
        dt = clamp(t - self.last_t, 0.0, TRACK_PREDICT_MAX_S)
        return self.pos + self.vel * dt

    def drop(self) -> None:
        self.confirmed = False
        self.pos = None
        self.vel = np.zeros(3, dtype=np.float64)
        self._samples.clear()
        self._pending.clear()

    # -- update ----------------------------------------------------------
    def update(self, t: float, sightings: list) -> Optional[Sighting]:
        if self.pos is not None and self.missing_time(t) > TRACK_DROP_S:
            self.drop()

        chosen = self._associate(t, sightings)

        if chosen is None:
            return None

        if self.pos is None:
            # acquisition: require CONFIRM_HITS mutually consistent sightings
            self._pending.append(chosen)
            if not self._acquire_ready(t):
                return None
            seed = self._pending[-1]
            self.pos = seed.pos.copy()
            self.last_t = seed.t_obs
            self._samples.clear()
            for s in self._pending:
                self._samples.append((s.t_obs, s.pos.copy()))
            self._pending.clear()
            self.confirmed = True
            self._estimate_velocity()
            return chosen

        # measurement update: position snaps to the sighting (the box IS the
        # measurement), velocity is smoothed.
        self.pos = chosen.pos.copy()
        self.last_t = chosen.t_obs
        self._samples.append((chosen.t_obs, chosen.pos.copy()))
        self._estimate_velocity()
        return chosen

    def _associate(self, t: float, sightings: list) -> Optional[Sighting]:
        if not sightings:
            return None
        if self.pos is None:
            # no track: prefer the higher-confidence box, let _acquire_ready
            # throw out anything that does not repeat consistently
            return max(sightings, key=lambda s: s.conf)
        best, best_d = None, 1e9
        for s in sightings:
            predicted = self.predict(s.t_obs)
            if predicted is None:
                continue
            d = float(np.linalg.norm(s.pos - predicted))
            gate = min(ASSOC_GATE_M + ASSOC_GATE_RATE_M_PER_S * self.missing_time(s.t_obs),
                       ASSOC_GATE_MAX_M)
            if d < gate and d < best_d:
                best, best_d = s, d
        return best

    def _acquire_ready(self, t: float) -> bool:
        fresh = [s for s in self._pending if t - s.t_obs <= 0.7]
        if len(fresh) < CONFIRM_HITS:
            return False
        # motion-compensated mutual consistency: a real target moves at most
        # TARGET_VEL_CLAMP between sightings; an anchored ghost re-rolls its
        # range every frame and blows the gate open.
        ref = fresh[-1]
        for s in fresh[:-1]:
            budget = ASSOC_GATE_M + TARGET_VEL_CLAMP * abs(ref.t_obs - s.t_obs)
            if float(np.linalg.norm(s.pos - ref.pos)) > budget:
                return False
        return True

    def _estimate_velocity(self) -> None:
        if len(self._samples) < 2:
            return
        (t0, p0), (t1, p1) = self._samples[0], self._samples[-1]
        span = t1 - t0
        if span < 1e-3:
            return
        raw = (p1 - p0) / span
        n = float(np.linalg.norm(raw))
        if n > TARGET_VEL_CLAMP:
            raw = raw * (TARGET_VEL_CLAMP / n)
        self.vel = (1.0 - VEL_EMA) * self.vel + VEL_EMA * raw


# ---------------------------------------------------------------------------
# guidance
# ---------------------------------------------------------------------------
def intercept_velocity(p_self: np.ndarray, p_tgt: np.ndarray, v_tgt: np.ndarray,
                       speed: float) -> np.ndarray:
    """Intercept-triangle solve.

    Solve ||r + v_t * t|| = speed * t for the earliest positive t, then fly
    straight at that meeting point. Degenerates to pure pursuit when the
    quadratic has no positive root -- which cannot happen here (the target's
    flee speed tops out at 1.95 m/s against our 3.0) but is kept for safety.
    """
    r = np.asarray(p_tgt, dtype=np.float64) - np.asarray(p_self, dtype=np.float64)
    a = float(np.dot(v_tgt, v_tgt)) - speed * speed
    b = 2.0 * float(np.dot(r, v_tgt))
    c = float(np.dot(r, r))
    t_hit = None
    if abs(a) < 1e-6:
        if abs(b) > 1e-9:
            cand = -c / b
            if cand > 1e-6:
                t_hit = cand
    else:
        disc = b * b - 4.0 * a * c
        if disc >= 0.0:
            sq = math.sqrt(disc)
            roots = sorted(x for x in ((-b - sq) / (2.0 * a), (-b + sq) / (2.0 * a)) if x > 1e-6)
            if roots:
                t_hit = roots[0]
    if t_hit is None:
        return unit(r) * speed
    aim = np.asarray(p_tgt, dtype=np.float64) + v_tgt * t_hit
    return unit(aim - p_self) * speed


# ---------------------------------------------------------------------------
# phases
# ---------------------------------------------------------------------------
class FreeSpace:
    """Union of balls around points known to be flyable.

    The validator ray-checks the target's own legs with clearance, so every
    confirmed sighting marks reachable space; past positions mark it too, by
    survival. Everything else is unvouched, and the guard below refuses to
    travel further into it; capping speed alone does not help, since contact
    happens at low speed as readily as high.
    """

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self._pts = np.zeros((FREE_MAX_POINTS, 3), dtype=np.float64)
        self._rad = np.zeros(FREE_MAX_POINTS, dtype=np.float64)
        self._n = 0

    def add(self, pos: np.ndarray, radius: float) -> None:
        if self._n >= FREE_MAX_POINTS:
            return
        p = np.asarray(pos, dtype=np.float64)
        if self._n:
            d = np.linalg.norm(self._pts[:self._n] - p, axis=1)
            if float(d.min()) < FREE_SPACING_M:
                # already covered; keep the more generous radius
                i = int(d.argmin())
                self._rad[i] = max(self._rad[i], radius)
                return
        self._pts[self._n] = p
        self._rad[self._n] = radius
        self._n += 1

    def margin(self, p: np.ndarray) -> Tuple[float, Optional[np.ndarray]]:
        """Signed distance outside the union, and the nearest centre."""
        if self._n == 0:
            return 0.0, None
        d = np.linalg.norm(self._pts[:self._n] - np.asarray(p, dtype=np.float64), axis=1)
        out = d - self._rad[:self._n]
        i = int(out.argmin())
        return float(out[i]), self._pts[i].copy()


class Phase:
    TAKEOFF = "TAKEOFF"
    SEARCH = "SEARCH"
    PURSUE = "PURSUE"
    REACQUIRE = "REACQUIRE"


class DroneFlightController:
    """Office interceptor controller."""

    def __init__(self) -> None:
        self.dr = DeadReckoner()
        self.projector = BoxProjector()
        self.tracker = TargetTracker()
        self.free = FreeSpace()
        self.reset()

    # -- lifecycle -------------------------------------------------------
    def reset(self) -> None:
        self.frame = 0
        self.dr.reset()
        self.projector.reset()
        self.tracker.reset()
        self.free.reset()
        self.phase = Phase.TAKEOFF
        self.sticks = np.zeros(4, dtype=np.float64)   # mirror of the env's slew state
        self._prev_det_age = -1.0
        self._prev_rpy = None
        self._search_yaw_sign = 1.0
        self._reacq_started = -1e9
        self._reacq_bias = 0.0
        self._last_bearing = 0.0
        self._prev_fix: Optional[np.ndarray] = None
        self._prev_fix_t = -1e9
        self._last_known: Optional[np.ndarray] = None
        self._last_known_vel = np.zeros(3, dtype=np.float64)
        self._last_known_t = -1e9
        self._alt_phase = 0.0

    # -- main ------------------------------------------------------------
    def act(self, observation) -> np.ndarray:
        t = self.frame * DT
        try:
            state = np.asarray(observation["state"], dtype=np.float64).reshape(-1)
            if state.size < 27 or not np.all(np.isfinite(state[:27])):
                raise ValueError
        except Exception:
            self.frame += 1
            return np.zeros(4, dtype=np.float32)

        self.dr.update(state)
        self.projector.push_pose(t, self.dr.pos, self.dr.roll, self.dr.pitch, self.dr.yaw)

        # Only ingest a detector frame ONCE. The obs holds the last boxes for
        # five control steps; the age field resets when a new frame lands, so a
        # decrease in age is the new-measurement edge.
        det_age = float(state[16])
        new_frame = (self._prev_det_age < 0.0) or (det_age < self._prev_det_age - 1e-9)
        self._prev_det_age = det_age

        sightings = self.projector.parse(state, t) if new_frame else []
        hit = self.tracker.update(t, sightings)
        if hit is not None:
            self._last_bearing = hit.bearing
            # the validator ray-checks each of the target's legs with clearance,
            # so the segment it just flew is free, not merely its endpoints
            if (self._prev_fix is not None
                    and t - self._prev_fix_t <= FREE_LEG_MAX_GAP_S):
                seg = hit.pos - self._prev_fix
                n = float(np.linalg.norm(seg))
                if 1e-6 < n < FREE_LEG_MAX_M:
                    for k in range(int(n / FREE_SPACING_M) + 2):
                        f = min(1.0, k * FREE_SPACING_M / n)
                        self.free.add(self._prev_fix + seg * f, FREE_TARGET_R)
            self._prev_fix = np.asarray(hit.pos, dtype=np.float64).copy()
            self._prev_fix_t = t
            self.free.add(hit.pos, FREE_TARGET_R)
        if self.dr.height > 0.8:
            self.free.add(self.dr.pos, FREE_SELF_R)
        if self.tracker.pos is not None:
            self._last_known = self.tracker.pos.copy()
            self._last_known_vel = self.tracker.vel.copy()
            self._last_known_t = self.tracker.last_t

        self.phase = self._next_phase(t)

        if self.phase == Phase.TAKEOFF:
            v_des, yaw_rate = self._takeoff()
        elif self.phase == Phase.SEARCH:
            v_des, yaw_rate = self._search(t)
        elif self.phase == Phase.PURSUE:
            v_des, yaw_rate = self._pursue(t)
        else:
            v_des, yaw_rate = self._reacquire(t)

        v_des = self._altitude_guard(v_des)
        v_des = self._free_space_guard(v_des, t)
        v_des = self._governor(v_des)

        action = self._to_sticks(v_des, yaw_rate)
        self.frame += 1
        return action

    # -- phase machine ---------------------------------------------------
    def _next_phase(self, t: float) -> str:
        if self.phase == Phase.TAKEOFF:
            if self.dr.height < TAKEOFF_DONE_M:
                return Phase.TAKEOFF
            return Phase.PURSUE if self.tracker.confirmed else Phase.SEARCH

        if self.tracker.confirmed and self.tracker.missing_time(t) < 0.35:
            return Phase.PURSUE

        if self.tracker.pos is not None:
            if self.phase != Phase.REACQUIRE:
                self._reacq_started = t
                self._reacq_bias = 0.0
            return Phase.REACQUIRE

        if self.phase == Phase.REACQUIRE and (t - self._reacq_started) < REACQUIRE_GIVE_UP_S:
            return Phase.REACQUIRE
        return Phase.SEARCH

    # -- behaviours ------------------------------------------------------
    def _takeoff(self):
        """Climb briskly into the target's band. The par time already grants
        6.5 s of acquire slack, but every second here is scored."""
        err = TAKEOFF_TARGET_M - self.dr.height
        vz = clamp(2.0 * err, -1.0, TAKEOFF_UD_STICK * RC_SPEED)
        return np.array([0.0, 0.0, vz], dtype=np.float64), 0.0

    def _search(self, t: float):
        """Yaw sweep from a stationary hover, with a slow altitude sweep.

        Never translate while blind. With no absolute position there is no
        wall to avoid against, and the target is the one moving: sitting still
        and sweeping converts the target's own patrol into coverage. The cost
        is that a target parked behind a partition can stay occluded.
        """
        self._alt_phase += DT / SEARCH_ALT_PERIOD_S
        mid = 0.5 * (SEARCH_ALT_LOW_M + SEARCH_ALT_HIGH_M)
        amp = 0.5 * (SEARCH_ALT_HIGH_M - SEARCH_ALT_LOW_M)
        z_want = mid + amp * math.sin(2.0 * math.pi * self._alt_phase)
        vz = clamp(1.5 * (z_want - self.dr.height), -SEARCH_VZ_MAX, SEARCH_VZ_MAX)
        return np.array([0.0, 0.0, vz], dtype=np.float64), SEARCH_YAW_RATE * self._search_yaw_sign

    def _pursue(self, t: float):
        p_t = self.tracker.predict(t)
        if p_t is None:
            return self._search(t)
        rel = p_t - self.dr.pos
        dist = float(np.linalg.norm(rel))

        if dist <= TERMINAL_RANGE_M:
            # Terminal: the catch is a physical hit and a deep-overlap guard
            # covers a fast approach, so there is nothing to be gained by
            # braking. Aim where the body will be one reaction-time from now
            # and drive through it.
            aim = p_t + self.tracker.vel * CONTACT_LEAD_S
            v_des = unit(aim - self.dr.pos) * PURSUE_SPEED
        else:
            v_des = intercept_velocity(self.dr.pos, p_t, self.tracker.vel, PURSUE_SPEED)

        # Match the target's altitude rather than diving at it: the flee reflex
        # is horizontal, so vertical error is pure miss distance.
        z_err = p_t[2] - self.dr.pos[2]
        v_des[2] = clamp(1.8 * z_err, -1.5, 1.5)

        if self.tracker.missing_time(t) > 0.2 and self.tracker.pos is not None:
            # the fix is stale: aim no further than a short step beyond it
            step = p_t - self.tracker.pos
            n = float(np.linalg.norm(step))
            if n > STALE_OVERSHOOT_M:
                p_t = self.tracker.pos + step * (STALE_OVERSHOOT_M / n)

        bearing_err = self._bearing_error(p_t + self.tracker.vel * YAW_LEAD_S)
        yaw_rate = clamp(YAW_KP * bearing_err, -RC_YAW_RATE, RC_YAW_RATE)

        # The detector only reports what the camera is looking at. If the target
        # is drifting out of frame, buy pointing before speed.
        if abs(bearing_err) > YAW_POINTING_ERR_RAD:
            v_des = v_des * 0.55
        return v_des, yaw_rate

    def _reacquire(self, t: float):
        """Fly the prediction briefly, then sweep around the last bearing.
        The yaw bias grows with time lost rather than jumping to a fixed
        offset, so a brief dropout costs little and a long one widens the
        search."""
        p_t = self.tracker.predict(t)
        v_t = self.tracker.vel
        if p_t is None and self._last_known is not None:
            # the track was dropped, but the last fix is still the best prior we
            # have -- extrapolate it (bounded) rather than falling back to a
            # blind open search that throws the information away
            dt_lost = clamp(t - self._last_known_t, 0.0, REACQ_EXTRAP_MAX_S)
            p_t = self._last_known + self._last_known_vel * dt_lost
            step = p_t - self._last_known
            n = float(np.linalg.norm(step))
            if n > REACQ_EXTRAP_MAX_M:
                p_t = self._last_known + step * (REACQ_EXTRAP_MAX_M / n)
            v_t = self._last_known_vel
        elapsed = t - self._reacq_started
        if p_t is None:
            return self._search(t)

        if elapsed < REACQUIRE_HOLD_S:
            v_des = intercept_velocity(self.dr.pos, p_t, v_t, PURSUE_SPEED * 0.7)
            v_des[2] = clamp(1.5 * (p_t[2] - self.dr.pos[2]), -1.0, 1.0)
            yaw_rate = clamp(YAW_KP * self._bearing_error(p_t), -RC_YAW_RATE, RC_YAW_RATE)
            return v_des, yaw_rate

        # sweep: widen a yaw bias around the last known bearing
        self._reacq_bias += REACQUIRE_SWEEP_RATE * DT * self._search_yaw_sign
        if abs(self._reacq_bias) > REACQUIRE_MAX_BIAS_RAD:
            self._search_yaw_sign *= -1.0
            self._reacq_bias = clamp(self._reacq_bias, -REACQUIRE_MAX_BIAS_RAD, REACQUIRE_MAX_BIAS_RAD)
        vz = clamp(1.5 * (p_t[2] - self.dr.pos[2]), -0.8, 0.8)
        yaw_rate = REACQUIRE_SWEEP_RATE * self._search_yaw_sign
        return np.array([0.0, 0.0, vz], dtype=np.float64), yaw_rate

    # -- helpers ---------------------------------------------------------
    def _bearing_error(self, p_world: np.ndarray) -> float:
        rel = np.asarray(p_world, dtype=np.float64) - self.dr.pos
        want = math.atan2(rel[1], rel[0])
        return wrap_angle(want - self.dr.yaw)

    def _altitude_guard(self, v_des: np.ndarray) -> np.ndarray:
        v = np.asarray(v_des, dtype=np.float64).copy()
        z = self.dr.pos[2]
        if z > ALT_MAX_M:
            v[2] = min(v[2], -0.4 * (z - ALT_MAX_M) - 0.1)
        elif z < ALT_MIN_M:
            v[2] = max(v[2], 0.6)
        # ToF sees the floor -- or a desk. Anything close underneath means we
        # are over furniture, not over the floor we think we are over.
        if 0.0 < self.dr.tof < TOF_FLOOR_GUARD_M:
            v[2] = max(v[2], 0.5)
        return v

    def _free_space_guard(self, v_des: np.ndarray, t: float) -> np.ndarray:
        """Refuse to travel further out of vouched space than we already are."""
        if not FREE_ENABLED:
            return v_des
        v = np.asarray(v_des, dtype=np.float64).copy()
        speed = float(np.linalg.norm(v[:2]))
        if speed < 1e-6:
            return v
        # closing on a fresh fix is never blocked: the target is standing in
        # free space, so the space we are closing into is reachable
        if (self.tracker.pos is not None
                and self.tracker.missing_time(t) < FREE_CLOSE_EXEMPT_S):
            to_t = unit((self.tracker.pos - self.dr.pos)[:2])
            if float(np.dot(to_t, unit(v[:2]))) > FREE_CLOSE_ALIGN:
                return v
        ahead = self.dr.pos + v * FREE_LOOKAHEAD_S
        margin, centre = self.free.margin(ahead)
        if centre is None or margin <= 0.0:
            return v
        here, _ = self.free.margin(self.dr.pos)
        if margin <= here:
            return v            # heading back toward known space is always fine
        outward = unit((ahead - centre)[:2])
        radial = float(np.dot(v[:2], outward))
        if radial > 0.0:
            v[:2] = v[:2] - outward * radial
        return v

    def _governor(self, v_des: np.ndarray) -> np.ndarray:
        """Bound the velocity error by the remaining tilt margin.

        This must be the LAST thing that touches the command: anything that
        scales the command afterwards re-opens the very error being bounded,
        since commanding zero while doing 3 m/s IS a 3 m/s error, which demands
        maximum deceleration and therefore maximum bank.

        Tilt rate is differentiated from the measured attitude; only pitch and
        roll are reported, so there is no rate signal to trust instead.
        """
        roll, pitch = self.dr.roll, self.dr.pitch
        rr = pr = 0.0
        if self._prev_rpy is not None:
            rr = (roll - self._prev_rpy[0]) / DT
            pr = (pitch - self._prev_rpy[1]) / DT
        self._prev_rpy = (roll, pitch)

        tilt_now = math.degrees(max(abs(roll), abs(pitch)))
        tilt_pred = math.degrees(max(
            abs(roll) + max(0.0, rr * math.copysign(1.0, roll)) * GOV_PREDICT_S,
            abs(pitch) + max(0.0, pr * math.copysign(1.0, pitch)) * GOV_PREDICT_S,
        ))
        tilt = max(tilt_now, tilt_pred)
        if tilt <= GOV_TILT_FREE_DEG:
            return v_des

        frac = clamp((GOV_TILT_LIMIT_DEG - tilt) / (GOV_TILT_LIMIT_DEG - GOV_TILT_FREE_DEG), 0.0, 1.0)
        allow = GOV_ERR_MIN_MPS + (GOV_ERR_MAX_MPS - GOV_ERR_MIN_MPS) * frac
        v = np.asarray(v_des, dtype=np.float64).copy()
        err = v[:2] - self.dr.vel[:2]
        mag = float(np.linalg.norm(err))
        if mag > allow:
            v[:2] = self.dr.vel[:2] + err / mag * allow
        return v

    def _to_sticks(self, v_des: np.ndarray, yaw_rate: float) -> np.ndarray:
        lr, fb, ud = world_to_sticks(v_des, self.dr.yaw)
        yaw_stick = yaw_rate / RC_YAW_RATE
        want = np.array([lr, fb, ud, yaw_stick], dtype=np.float64)
        want = np.clip(want, -1.0, 1.0)

        # Mirror the env's slew limiter so our internal idea of the commanded
        # stick matches what the airframe is actually given. Asking for a step
        # the env will smooth anyway only makes the estimate wrong.
        max_step = RC_SLEW_PER_SEC * DT
        self.sticks = self.sticks + np.clip(want - self.sticks, -max_step, max_step)

        out = self.sticks.copy()
        out[np.abs(out) < RC_DEAD_ZONE] = 0.0     # the env reads these as zero
        if not np.all(np.isfinite(out)):
            return np.zeros(4, dtype=np.float32)
        return out.astype(np.float32)
